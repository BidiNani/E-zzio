from dataclasses import dataclass, field
from typing import List, Dict

@dataclass
class CapabilityManifest:
    name: str
    version: str
    permissions: List[str]
    memory_limit_mb: int
    timeout_sec: int
    signature: str
    is_verified: bool = False

class CapabilityRegistry:
    """Registre durci des capacités : rejette tout manifeste non signé ou incomplet."""
    
    def __init__(self):
        self._manifests: Dict[str, CapabilityManifest] = {}

    def register(self, manifest_data: dict) -> tuple[bool, str]:
        # Validation rigoureuse des champs obligatoires
        required_fields = {"name", "version", "permissions", "memory_limit_mb", "timeout_sec", "signature"}
        missing = required_fields.difference(manifest_data.keys())
        if missing:
            return False, f"Manifeste rejeté : champs manquants {sorted(missing)}"

        # Vérification de la signature (simulée stricte pour V4.2.2, asymétrique en V4.3)
        sig = manifest_data.get("signature", "")
        if not sig or len(sig) < 32:
            return False, "Manifeste rejeté : Signature cryptographique invalide ou absente."

        manifest = CapabilityManifest(
            name=manifest_data["name"],
            version=manifest_data["version"],
            permissions=manifest_data["permissions"],
            memory_limit_mb=manifest_data["memory_limit_mb"],
            timeout_sec=manifest_data["timeout_sec"],
            signature=sig,
            is_verified=True
        )
        
        self._manifests[manifest.name] = manifest
        return True, "MANIFEST_REGISTERED_SUCCESS"

    def get_permissions(self, capability_name: str) -> List[str]:
        manifest = self._manifests.get(capability_name)
        if manifest and manifest.is_verified:
            return manifest.permissions
        return []