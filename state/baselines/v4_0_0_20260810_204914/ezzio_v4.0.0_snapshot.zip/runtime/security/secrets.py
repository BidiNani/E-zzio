import os
import secrets
import hashlib
import time
from pathlib import Path
import datetime

class SecretProvider:
    """Vault avec cache mémoire obfusqué, Wipe Memory (zéroïsation) et TTL individuel."""
    
    def __init__(self, cache_ttl=300):
        self._cache = {}
        self._obfuscation_key = secrets.token_bytes(32)
        self._last_env_hash = None
        self._last_audit_error = None
        self._cache_ttl = cache_ttl
        self._env_paths = [
            Path(__file__).resolve().parent.parent.parent / "secrets" / ".env",
            Path("G:/AI/E-zzio/secrets/.env"),
            Path("secrets/.env")
        ]

    def _obfuscate(self, data: str) -> bytes:
        b_data = data.encode('utf-8')
        return bytes(a ^ b for a, b in zip(b_data, self._obfuscation_key * (len(b_data) // len(self._obfuscation_key) + 1)))

    def _deobfuscate(self, b_data: bytes) -> str:
        decrypted = bytes(a ^ b for a, b in zip(b_data, self._obfuscation_key * (len(b_data) // len(self._obfuscation_key) + 1)))
        return decrypted.decode('utf-8')

    def _wipe_memory(self, b_data: bytes):
        """Tente d'écraser la donnée en mémoire (zéroïsation)."""
        try:
            arr = bytearray(b_data)
            for i in range(len(arr)):
                arr[i] = 0
        except Exception:
            pass

    def _get_active_env_path(self) -> Path:
        for path in self._env_paths:
            if path.exists():
                return path
        return None

    def _compute_file_hash(self, path: Path) -> str:
        hasher = hashlib.sha256()
        try:
            with open(path, 'rb') as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hasher.update(chunk)
            return hasher.hexdigest()
        except Exception:
            return None

    def _log_rotation_event(self, secret_name: str, old_hash: str, new_hash: str):
        timestamp = datetime.datetime.now().isoformat()
        secret_id = hashlib.sha256(secret_name.encode('utf-8')).hexdigest()[:16]
        log_entry = f"[{timestamp}] SECRET_ROTATION_EVENT | SecretID: {secret_id} | Old: {old_hash} | New: {new_hash}\n"
        try:
            log_path = Path("G:/AI/E-zzio/logs/security_audit.log")
            if not log_path.parent.exists():
                log_path.parent.mkdir(parents=True, exist_ok=True)
            with open(log_path, 'a', encoding="utf-8") as f:
                f.write(log_entry)
            self._last_audit_error = None
        except Exception as e:
            self._last_audit_error = f"Audit log write failed: {str(e)}"

    def _refresh_cache_if_needed(self):
        env_path = self._get_active_env_path()
        if not env_path:
            return

        now = time.time()
        
        # 1. Purge ciblée et Wipe Memory des clés expirées
        expired_keys = [k for k, v in self._cache.items() if now > v[1]]
        for k in expired_keys:
            expired_data = self._cache.pop(k, None)
            if expired_data:
                self._wipe_memory(expired_data[0])

        current_hash = self._compute_file_hash(env_path)
        
        # 2. Rechargement complet + Rotation de la clé RAM si le fichier a muté
        if current_hash != self._last_env_hash:
            old_cache_hashes = {k: hashlib.sha256(self._deobfuscate(v[0]).encode()).hexdigest() for k, v in self._cache.items()}
            
            # Wipe total du cache existant
            for k, v in self._cache.items():
                self._wipe_memory(v[0])
            self._cache.clear()
            
            # Rotation de la clé d'obfuscation RAM
            self._obfuscation_key = secrets.token_bytes(32)
            
            try:
                for line in env_path.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        k, v = line.split("=", 1)
                        clean_val = v.strip().strip('"\'')
                        self._cache[k.strip()] = (self._obfuscate(clean_val), now + self._cache_ttl)
                
                self._last_env_hash = current_hash
                
                for key, (enc_val, _) in self._cache.items():
                    new_val_hash = hashlib.sha256(self._deobfuscate(enc_val).encode()).hexdigest()
                    old_val_hash = old_cache_hashes.get(key)
                    if old_val_hash and old_val_hash != new_val_hash:
                         self._log_rotation_event(key, old_val_hash, new_val_hash)
                    elif not old_val_hash and old_cache_hashes:
                         self._log_rotation_event(key, "NONE", new_val_hash)
            except Exception as e:
                self._last_audit_error = f"Cache refresh failed: {str(e)}"

    def get(self, secret_name: str) -> str:
        self._refresh_cache_if_needed()
        cache_entry = self._cache.get(secret_name)
        if cache_entry and time.time() <= cache_entry[1]:
            return self._deobfuscate(cache_entry[0])
        return os.environ.get(secret_name)

    def get_hash(self, secret_name: str) -> str:
        val = self.get(secret_name)
        return hashlib.sha256(val.encode()).hexdigest() if val else None

secret_provider = SecretProvider()

class SecretKeyManager:
    def __init__(self):
        env_key = secret_provider.get("EZZIO_HMAC_SECRET")
        if env_key:
            self._key = env_key.encode("utf-8")
            self.key_id = secret_provider.get("EZZIO_KEY_ID") or "env-key"
        else:
            self._key = secrets.token_bytes(32)
            self.key_id = "ephemeral-key"

    def get_key(self) -> bytes:
        return self._key