import hashlib
import json
from pathlib import Path

class TrustRegistry:
    """Garant de l'intégrité cryptographique des composants E-ZZIO."""
    
    def __init__(self, root_path: Path):
        self.root = root_path

    def verify_file(self, filepath: Path, sigpath: Path) -> bool:
        """Vérifie l'intégrité d'un fichier par rapport à sa signature (.sig)."""
        if not filepath.exists() or not sigpath.exists():
            return False
            
        try:
            raw_bytes = filepath.read_bytes()
            calculated_hash = hashlib.sha256(raw_bytes).hexdigest()
            
            sig_data = json.loads(sigpath.read_text(encoding="utf-8"))
            expected_hash = sig_data.get("hash")
            
            return calculated_hash == expected_hash
        except Exception:
            return False