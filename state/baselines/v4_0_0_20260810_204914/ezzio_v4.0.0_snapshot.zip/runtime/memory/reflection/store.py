import sqlite3
import json
from runtime.core.events import EventBus
from runtime.memory.sqlite.store import SQLiteEventStore

class ReflectionProposalStore:
    """Intercepte les enveloppes de propositions versionnées et les persiste en base."""
    def __init__(self, store: SQLiteEventStore, event_bus: EventBus):
        self.store = store
        self.event_bus = event_bus

        self._init_schema()
        self.event_bus.subscribe("ReflectionProposalGenerated", self.save_proposals)


    def _init_schema(self):
        """
        Initialise automatiquement la table des propositions réflexives.
        Auto-healing SQLite.
        """

        with self.store._lock:
            with sqlite3.connect(self.store.db_path) as conn:
                conn.execute("""
                CREATE TABLE IF NOT EXISTS reflection_proposals (
                    proposal_id TEXT PRIMARY KEY,
                    type TEXT NOT NULL,
                    statement TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    evidence TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
                """)

    def save_proposals(self, envelope: dict):
        # Supporte l'enveloppe versionnée ou une liste brute par rétrocompatibilité
        proposals = envelope.get("proposals", envelope) if isinstance(envelope, dict) else envelope
        if not isinstance(proposals, list) or not proposals: return

        with self.store._lock:
            with sqlite3.connect(self.store.db_path) as conn:
                for prop in proposals:
                    conn.execute(
                        "INSERT OR REPLACE INTO reflection_proposals (proposal_id, type, statement, confidence, evidence, status, created_at) VALUES (?, ?, ?, ?, ?, ?, datetime('now'))",
                        (prop["proposal_id"], prop["type"], prop["statement"], prop["confidence"], json.dumps(prop["evidence"]), "PENDING")
                    )
        self.event_bus.emit("AuditLog", {"message": f"ReflectionProposalStore : {len(proposals)} propositions (contrat v{envelope.get('version', 'unknown')}) persistées.", "level": "INFO"})

